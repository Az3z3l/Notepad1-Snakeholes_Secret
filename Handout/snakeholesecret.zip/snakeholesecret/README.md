## Server

- docker build -t notepad1 .
- docker run -p 80:3000 notepad1
- access the challenge on localhost

## Bot

- Requires puppeteer with latest version of chrome 